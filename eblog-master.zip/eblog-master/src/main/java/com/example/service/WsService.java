package com.example.service;

public interface WsService {
    void sendMessCountToUser(Long toUserId);
}
