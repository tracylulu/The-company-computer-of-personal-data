package com.example;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EblogApplicationTests {

    @Test
    void contextLoads() {

        System.out.println(1);
    }

}
